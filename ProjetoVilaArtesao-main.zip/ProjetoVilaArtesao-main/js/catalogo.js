document.addEventListener('DOMContentLoaded', function() {
    fetch('produtos.json') // Caminho JSON
        .then(response => response.json())
        .then(produtos => {
            const catalogo = document.getElementById('catalogo');

            if (Array.isArray(produtos)) {
                produtos.forEach(produto => {
                    const produtoHTML = `
                        <div class="product">
                            <img src="${produto.imagem}" alt="${produto.nome}">
                            <h3>${produto.nome}</h3>
                            <p>${produto.descricao}</p>
                            <p>Preço: R$ ${produto.preco.toFixed(2)}</p>
                            <button class="adicionar-carrinho">Adicionar ao Carrinho</button>
                        </div>
                    `;
                    catalogo.innerHTML += produtoHTML;
                });
            } else {
                const produtoHTML = `
                    <div class="product">
                        <img src="${produtos.imagem}" alt="${produtos.nome}">
                        <h3>${produtos.nome}</h3>
                        <p>${produtos.descricao}</p>
                        <p>Preço: R$ ${produtos.preco.toFixed(2)}</p>
                        <button class="adicionar-carrinho">Adicionar ao Carrinho</button>
                    </div>
                `;
                catalogo.innerHTML += produtoHTML;
            }
        
            // Evento de clique de adicionar ao carrinho
            document.querySelectorAll('.adicionar-carrinho').forEach(button => {
                button.addEventListener('click', function(event) {
                    const productDiv = event.target.closest('.product');
                    const nome = productDiv.querySelector('h3').textContent;
                    const descricao = productDiv.querySelector('p').textContent;
                    const imagem = productDiv.querySelector('img').src;
                    const preco = parseFloat(productDiv.querySelectorAll('p')[1].textContent.replace('Preço: R$ ', '').replace(',', '.'));

                    const produto = {
                        nome: nome,
                        descricao: descricao,
                        imagem: imagem,
                        preco: preco
                    };

                    adicionarAoCarrinho(produto);
                });
            });
        })
        .catch(error => console.error('Erro ao carregar produtos:', error));

    carregarCarrinho();

    // Evento de clique para o botão de limpar carrinho
    document.getElementById('clear-cart').addEventListener('click', limparCarrinho);

    // Evento de clique para o botão de finalizar compra
    document.getElementById('checkout').addEventListener('click', finalizarCompra);
});

function adicionarAoCarrinho(produto) {
    let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    carrinho.push(produto);
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    carregarCarrinho();
}

function carregarCarrinho() {
    const carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');

    cartItems.innerHTML = ''; // Limpa o conteúdo

    if (carrinho.length === 0) {
        cartItems.innerHTML = '<p>O carrinho está vazio.</p>';
        cartTotal.textContent = '0,00';
    } else {
        let total = 0;

        carrinho.forEach((produto, index) => {
            const produtoHTML = `
                <div class="carrinho-item" data-index="${index}">
                    <img src="${produto.imagem}" alt="${produto.nome}">
                    <div>
                        <h3>${produto.nome}</h3>
                        <p>${produto.descricao}</p>
                        <p>Preço: R$ ${produto.preco.toFixed(2)}</p>
                    </div>
                    <button class="remover-item">Remover</button>
                </div>
            `;
            cartItems.innerHTML += produtoHTML;
            total += produto.preco;
        });

        cartTotal.textContent = total.toFixed(2).replace('.', ',');

        // Adiciona evento de remover item
        document.querySelectorAll('.remover-item').forEach(button => {
            button.addEventListener('click', function(event) {
                const itemIndex = event.target.closest('.carrinho-item').dataset.index;
                removerItemDoCarrinho(itemIndex);
            });
        });
    }
}

// Remove item do carrinho
function removerItemDoCarrinho(index) {
    let carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];
    carrinho.splice(index, 1);
    localStorage.setItem('carrinho', JSON.stringify(carrinho));
    carregarCarrinho();
}
// Limpa o carrinho
function limparCarrinho() {
    localStorage.removeItem('carrinho');
    carregarCarrinho();
}
// Finaliza a compra
function finalizarCompra() {
    alert('Compra finalizada!');
    limparCarrinho();
}
